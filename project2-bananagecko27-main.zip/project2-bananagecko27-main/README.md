# project2
This is the second project using QtSpim and Github Classroom.
Please test your code thoroughly on your laptop before submitting for auto-grading.
Your grade will be based on your last attempt. 

Note that you cannot make any changes to run.sh or run1.sh.
